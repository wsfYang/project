package com.eservice.iot.service;
import com.eservice.iot.model.user.User;
import com.eservice.iot.core.Service;

/**
* Class Description: xxx
* @author Wilson Hu
* @date 2018/08/21.
*/
public interface UserService extends Service<User> {

}
