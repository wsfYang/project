package com.eservice.iot.service.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.util.Random;

@Service
public class MailService {

    @Value("${spring.mail.username}")
    private String from;

    @Autowired
    private JavaMailSender mailSender;

//    @Autowired
//    private MailSender sender;

    @Resource
    private TemplateEngine templateEngine;

    /**
     *  发送一个文本邮件
     */
    public void sendSimpleMail(String to,String subject,String content){
        SimpleMailMessage mail =new SimpleMailMessage();
        mail.setTo(to);
        mail.setSubject(subject);
        mail.setText(content);
        mail.setFrom(from);
        mail.setCc(from);
        mailSender.send(mail);
    }

    /**
     * 发送html邮件
     */
    public void sendHtmlMail(String to , String subject , String content){
        MimeMessage message =mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper =new MimeMessageHelper(message,true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content,true);
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    /**
     * 带有附件的邮件, 可以把附件装进list集合中，然后放入多个附件
     */
    public void sendAttachmentsMail(String to ,String subject,String content , String filePath){

        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(message,true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content,true);
            FileSystemResource file =new FileSystemResource(new File(filePath));
            String fileName = file.getFilename();
            //在这里可以add 多个附件，我这里就是为了测试说明，放了两个相同的文件，但是名字不同的。
            helper.addAttachment(fileName,file);
            helper.addAttachment(fileName+"_2",file);
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }

    }

    /**
     * 带有图片的邮件
     */
    public void sendImageMail(String to ,String subject,String content , String filePath,String srcId){

        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = null;
        try {
            helper = new MimeMessageHelper(message,true);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content,true);
            FileSystemResource file =new FileSystemResource(new File(filePath));
            helper.addInline(srcId,file);
            mailSender.send(message);
        } catch (MessagingException e) {
            e.printStackTrace();
        }

    }
    /**
     * 使用模版发送邮件
     */
    public void sendTemplateMail(String to ,String subject, String content){
        Context context = new Context();
        context.setVariable("validvalue", new Random().nextInt(999999));

        String templateContext = templateEngine.process("emailTemplate",context);
        sendHtmlMail(to,subject,templateContext);
    }
}
