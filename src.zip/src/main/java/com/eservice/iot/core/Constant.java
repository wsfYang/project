package com.eservice.iot.core;

/**
 * Class Description:
 *
 * @author Wilson Hu
 * @date 8/15/2018
 */
public class Constant {
    public static final String VISITOR = "VISITOR";
    public static final String STAFF = "STAFF";
    public static final String STRANGER = "STRANGER";
    public static final String VIP = "VIP";
}
